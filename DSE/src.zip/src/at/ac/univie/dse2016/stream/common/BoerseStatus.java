package at.ac.univie.dse2016.stream.common;

public enum BoerseStatus {
	Open, Closed, Error
}
