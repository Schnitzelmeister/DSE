package at.ac.univie.dse2016.stream;

public enum BoerseStatus {
	Open, Closed, Error
}

