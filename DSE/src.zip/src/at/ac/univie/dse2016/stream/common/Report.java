package at.ac.univie.dse2016.stream.common;

import java.io.Serializable;

public abstract class Report implements Serializable {
	private static final long serialVersionUID = 100L;
	
}