package at.ac.univie.dse2016.stream;

import java.io.Serializable;

public abstract class Report implements Serializable {

}
