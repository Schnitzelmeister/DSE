package at.ac.univie.dse2016.stream;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.print("Parameter: show |<id>, add <pkw|lkw> ..., del <id>, count |<pkw|lkw>, meanage |<pkw|lkw>, oldest\n");
		
	}

}
