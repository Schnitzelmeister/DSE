package at.ac.univie.dse2016.stream;

import java.io.Serializable;

public class Geldgeber {
	protected Integer id;
	protected String name;
	protected String phone;
	
	public Integer getId() { return id; }
	public String getName() { return name; }
	public String getPhone() { return phone; }
}
