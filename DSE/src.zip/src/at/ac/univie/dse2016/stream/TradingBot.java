package at.ac.univie.dse2016.stream;

public class TradingBot {
	public void Start(Client client) {
		
	}
}
